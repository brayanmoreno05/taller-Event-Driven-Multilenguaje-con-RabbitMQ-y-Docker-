import os, json, time, pika

HOST = os.getenv("RABBIT_HOST", "localhost"); PORT = int(os.getenv("RABBIT_PORT", "5672"))
USER = os.getenv("RABBIT_USER", "guest");     PASS = os.getenv("RABBIT_PASS", "guest")
EXCHANGE = os.getenv("EXCHANGE", "shop.events")
NAME = "billing-py"; QUEUE = "q.billing"; KEYS = ["order.created", "payment.*"]

def connect():
    while True:
        try:
            return pika.BlockingConnection(pika.ConnectionParameters(
                host=HOST, port=PORT, credentials=pika.PlainCredentials(USER, PASS), heartbeat=30))
        except Exception as e:
            print(f"[{NAME}] broker no disponible ({e}); reintentando en 5s")
            time.sleep(5)

def on_message(ch, method, props, body):
    print(f"[{NAME}] <- {method.routing_key} {json.loads(body)}")
    ch.basic_ack(delivery_tag=method.delivery_tag)

ch = connect().channel()
ch.exchange_declare(exchange=EXCHANGE, exchange_type="topic", durable=True)
ch.queue_declare(queue=QUEUE, durable=True)
for k in KEYS:
    ch.queue_bind(queue=QUEUE, exchange=EXCHANGE, routing_key=k)
ch.basic_qos(prefetch_count=10)
ch.basic_consume(queue=QUEUE, on_message_callback=on_message)
print(f"[{NAME}] escuchando {KEYS} en cola {QUEUE}")
ch.start_consuming()
