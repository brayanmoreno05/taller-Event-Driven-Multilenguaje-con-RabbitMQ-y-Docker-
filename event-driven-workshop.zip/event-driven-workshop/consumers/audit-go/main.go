package main

import (
	"fmt"
	"log"
	"os"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
)

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

func main() {
	url := fmt.Sprintf("amqp://%s:%s@%s:%s/", env("RABBIT_USER", "guest"), env("RABBIT_PASS", "guest"),
		env("RABBIT_HOST", "localhost"), env("RABBIT_PORT", "5672"))
	ex := env("EXCHANGE", "shop.events")
	const queue = "q.audit"
	keys := []string{"payment.*", "inventory.*"}

	var conn *amqp.Connection
	var err error
	for {
		if conn, err = amqp.Dial(url); err == nil {
			break
		}
		log.Printf("[audit-go] broker no disponible (%v); reintentando en 5s", err)
		time.Sleep(5 * time.Second)
	}
	ch, err := conn.Channel()
	if err != nil {
		log.Fatal(err)
	}
	if err := ch.ExchangeDeclare(ex, "topic", true, false, false, false, nil); err != nil {
		log.Fatal(err)
	}
	if _, err := ch.QueueDeclare(queue, true, false, false, false, nil); err != nil {
		log.Fatal(err)
	}
	for _, k := range keys {
		if err := ch.QueueBind(queue, k, ex, false, nil); err != nil {
			log.Fatal(err)
		}
	}
	ch.Qos(10, 0, false)
	msgs, err := ch.Consume(queue, "", false, false, false, false, nil)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("[audit-go] escuchando %v en cola %s", keys, queue)
	for d := range msgs {
		log.Printf("[audit-go] <- %s %s", d.RoutingKey, d.Body)
		d.Ack(false)
	}
}
