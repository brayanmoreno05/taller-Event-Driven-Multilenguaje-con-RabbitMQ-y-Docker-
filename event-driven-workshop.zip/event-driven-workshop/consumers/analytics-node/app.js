const amqp = require('amqplib');
const H = process.env.RABBIT_HOST || 'localhost', P = process.env.RABBIT_PORT || '5672';
const U = process.env.RABBIT_USER || 'guest', W = process.env.RABBIT_PASS || 'guest';
const EX = process.env.EXCHANGE || 'shop.events';
const QUEUE = 'q.analytics', KEYS = ['#'];   // recibe TODOS los eventos
const sleep = ms => new Promise(r => setTimeout(r, ms));
const counts = {};

async function connect() {
  for (;;) {
    try { return await amqp.connect(`amqp://${U}:${W}@${H}:${P}`); }
    catch (e) { console.log(`[analytics-node] broker no disponible (${e.message}); reintentando en 5s`); await sleep(5000); }
  }
}

(async () => {
  const conn = await connect();
  const ch = await conn.createChannel();
  await ch.assertExchange(EX, 'topic', { durable: true });
  await ch.assertQueue(QUEUE, { durable: true });
  for (const k of KEYS) await ch.bindQueue(QUEUE, EX, k);
  await ch.prefetch(10);
  console.log(`[analytics-node] escuchando ${KEYS} en cola ${QUEUE}`);
  ch.consume(QUEUE, msg => {
    const key = msg.fields.routingKey;
    counts[key] = (counts[key] || 0) + 1;
    console.log(`[analytics-node] <- ${key} | contadores: ${JSON.stringify(counts)}`);
    ch.ack(msg);
  });
})();
