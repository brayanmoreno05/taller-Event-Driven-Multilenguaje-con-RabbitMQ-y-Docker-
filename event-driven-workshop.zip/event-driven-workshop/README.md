# Taller Event-Driven con RabbitMQ + Docker

Exchange `shop.events` (topic, durable).

| Productor | Lenguaje | Routing key |
|---|---|---|
| orders | Python | order.created |
| payments | Node.js | payment.processed |
| inventory | Go | inventory.low |
| shipping | Python | shipping.dispatched |

| Consumidor | Lenguaje | Cola | Bindings |
|---|---|---|---|
| notifications | Python | q.notifications | order.*, shipping.* |
| analytics | Node.js | q.analytics | # |
| audit | Go | q.audit | payment.*, inventory.* |
| billing | Python | q.billing | order.created, payment.* |

Panel: http://IP_BROKER:15672 (admin / admin123)

## Escenario 1
    cd scenario1-centralizado && docker compose up --build

## Escenario 2 (clonar el repo en ambos nodos)
    # Nodo 2 (broker)
    cd scenario2-2nodos/node2-broker && docker compose up -d
    # Nodo 1 (servicios)
    cd scenario2-2nodos/node1-servicios && cp .env.example .env   # editar BROKER_HOST con la IP del Nodo 2
    docker compose up --build

## Escenario 3
    # Nodo 3 (broker)
    cd scenario3-3nodos/node3-broker && docker compose up -d
    # Nodos 1 y 2
    cd scenario3-3nodos/node1-servicios && cp .env.example .env   # editar BROKER_HOST con la IP del Nodo 3
    docker compose up --build        # igual en node2-servicios

Logs: `docker compose logs -f`. Abrir puertos 5672 y 15672 en el firewall del nodo del broker.
Detener: `docker compose down` (con `-v` borra las colas persistentes).
