package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"os"
	"strconv"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
)

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

func main() {
	url := fmt.Sprintf("amqp://%s:%s@%s:%s/", env("RABBIT_USER", "guest"), env("RABBIT_PASS", "guest"),
		env("RABBIT_HOST", "localhost"), env("RABBIT_PORT", "5672"))
	ex := env("EXCHANGE", "shop.events")
	sec, _ := strconv.ParseFloat(env("INTERVAL_SEC", "3"), 64)
	const key = "inventory.low"

	var conn *amqp.Connection
	var err error
	for {
		if conn, err = amqp.Dial(url); err == nil {
			break
		}
		log.Printf("[inventory-go] broker no disponible (%v); reintentando en 5s", err)
		time.Sleep(5 * time.Second)
	}
	ch, err := conn.Channel()
	if err != nil {
		log.Fatal(err)
	}
	if err := ch.ExchangeDeclare(ex, "topic", true, false, false, false, nil); err != nil {
		log.Fatal(err)
	}
	log.Println("[inventory-go] conectado")
	skus := []string{"SKU-100", "SKU-200", "SKU-300", "SKU-400"}
	for {
		body, _ := json.Marshal(map[string]any{
			"id": rand.Intn(100000), "producer": "inventory-go", "sku": skus[rand.Intn(len(skus))],
			"stock": rand.Intn(10), "ts": time.Now().Unix(),
		})
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		err := ch.PublishWithContext(ctx, ex, key, false, false, amqp.Publishing{
			ContentType: "application/json", DeliveryMode: amqp.Persistent, Body: body})
		cancel()
		if err != nil {
			log.Fatal(err)
		}
		log.Printf("[inventory-go] -> %s %s", key, body)
		time.Sleep(time.Duration(sec * float64(time.Second)))
	}
}
