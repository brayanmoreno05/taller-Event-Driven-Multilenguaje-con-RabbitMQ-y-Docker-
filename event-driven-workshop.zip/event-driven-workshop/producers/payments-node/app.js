const amqp = require('amqplib');
const H = process.env.RABBIT_HOST || 'localhost', P = process.env.RABBIT_PORT || '5672';
const U = process.env.RABBIT_USER || 'guest', W = process.env.RABBIT_PASS || 'guest';
const EX = process.env.EXCHANGE || 'shop.events';
const INTERVAL = parseFloat(process.env.INTERVAL_SEC || '3') * 1000;
const KEY = 'payment.processed';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function connect() {
  for (;;) {
    try { return await amqp.connect(`amqp://${U}:${W}@${H}:${P}`); }
    catch (e) { console.log(`[payments-node] broker no disponible (${e.message}); reintentando en 5s`); await sleep(5000); }
  }
}

(async () => {
  const conn = await connect();
  const ch = await conn.createChannel();
  await ch.assertExchange(EX, 'topic', { durable: true });
  console.log(`[payments-node] conectado a ${H}:${P}`);
  setInterval(() => {
    const ev = { id: Math.random().toString(36).slice(2, 10), producer: 'payments-node',
      method: ['card', 'pse', 'cash'][Math.floor(Math.random() * 3)],
      amount: +(Math.random() * 500 + 10).toFixed(2), status: 'approved', ts: Date.now() / 1000 };
    ch.publish(EX, KEY, Buffer.from(JSON.stringify(ev)), { persistent: true, contentType: 'application/json' });
    console.log(`[payments-node] -> ${KEY}`, JSON.stringify(ev));
  }, INTERVAL);
})();
