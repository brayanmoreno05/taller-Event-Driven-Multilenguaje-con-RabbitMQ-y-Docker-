import os, json, time, random, uuid, pika

HOST = os.getenv("RABBIT_HOST", "localhost"); PORT = int(os.getenv("RABBIT_PORT", "5672"))
USER = os.getenv("RABBIT_USER", "guest");     PASS = os.getenv("RABBIT_PASS", "guest")
EXCHANGE = os.getenv("EXCHANGE", "shop.events"); INTERVAL = float(os.getenv("INTERVAL_SEC", "3"))
NAME = "orders-py"; ROUTING_KEY = "order.created"

def connect():
    while True:
        try:
            return pika.BlockingConnection(pika.ConnectionParameters(
                host=HOST, port=PORT, credentials=pika.PlainCredentials(USER, PASS), heartbeat=30))
        except Exception as e:
            print(f"[{NAME}] broker no disponible ({e}); reintentando en 5s")
            time.sleep(5)

ch = connect().channel()
ch.exchange_declare(exchange=EXCHANGE, exchange_type="topic", durable=True)
print(f"[{NAME}] conectado a {HOST}:{PORT}")
while True:
    event = {"id": str(uuid.uuid4())[:8], "producer": NAME, "ts": time.time(), "customer": random.choice(["ana","luis","sofia","mateo"]), "items": random.randint(1,5), "total": round(random.uniform(10,500),2)}
    ch.basic_publish(exchange=EXCHANGE, routing_key=ROUTING_KEY, body=json.dumps(event),
                     properties=pika.BasicProperties(content_type="application/json", delivery_mode=2))
    print(f"[{NAME}] -> {ROUTING_KEY} {event}")
    time.sleep(INTERVAL)
